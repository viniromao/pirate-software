export default class PlayerData {
    static selectedCharacter = null;
}