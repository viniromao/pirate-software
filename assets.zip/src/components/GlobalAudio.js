const GlobalAudio = {
    music: null,
};

export default GlobalAudio;